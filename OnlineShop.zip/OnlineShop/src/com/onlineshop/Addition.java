package com.onlineshop;

public class Addition extends ProductDetails{
	Addition a = new Addition();
	public void getBill(int orderId) {
		
		ProductDetails productdetails = new ProductDetails();
		
	   //productdetails.billingMethod(a);
	}

}
