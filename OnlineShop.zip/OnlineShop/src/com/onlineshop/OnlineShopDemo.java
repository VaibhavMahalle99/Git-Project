package com.onlineshop;

public interface OnlineShopDemo {
	
	public abstract void adminLogin();
	
	//public abstract void registerUser();
	
	//public void loginUser();

}
